from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from .models import Store, Rating, User
from django.contrib import messages
from django.db.models import Count

def home(request):
    return render(request, 'ratings/login.html')

def register(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
       # address = request.POST['address']
        address = request.POST.get('address', '')  # Returns empty string if missing
        role = request.POST.get('role', '')  
        #role = request.POST['role']

        if len(name) < 20 or len(name) > 60:
            messages.error(request, "Name should be 20-60 characters long.")
        elif len(password) < 8 or len(password) > 16 or not any(c.isupper() for c in password) or not any(c in "!@#$%^&*" for c in password):
            messages.error(request, "Password must be 8-16 characters, with 1 uppercase & 1 special char.")
        else:
            user = User.objects.create_user(username=email, email=email, password=password, role=role, address=address, first_name=name)
            user.save()
            messages.success(request, "Account created successfully! You can login now.")
            return redirect('login')

    return render(request, 'ratings/register.html')

def login_view(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = authenticate(request, username=email, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid email or password.")
    
    return render(request, 'ratings/login.html')

@login_required
def dashboard(request):
    if request.user.role == 'admin':
        total_users = User.objects.count()
        total_stores = Store.objects.count()
        total_ratings = Rating.objects.count()
        return render(request, 'ratings/dashboard.html', {
            'total_users': total_users,
            'total_stores': total_stores,
            'total_ratings': total_ratings,
        })
    elif request.user.role == 'owner':
        store = Store.objects.get(owner=request.user)
        ratings = Rating.objects.filter(store=store)
        avg_rating = store.average_rating()
        return render(request, 'ratings/dashboard.html', {'ratings': ratings, 'avg_rating': avg_rating})
    else:
        stores = Store.objects.all()
        return render(request, 'ratings/store_list.html', {'stores': stores})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


#from django.shortcuts import render

def base_view(request):
    return render(request, 'base.html')  

def dashboard_view(request):
    return render(request, 'dashboard.html')  






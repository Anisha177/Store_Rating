from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models
from django.conf import settings

class User(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('normal', 'Normal User'),
        ('owner', 'Store Owner'),
    ]
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='normal')
    address = models.TextField(max_length=400)

    # Fixing the related_name issue
    groups = models.ManyToManyField(Group, related_name="ratings_users", blank=True)
    user_permissions = models.ManyToManyField(Permission, related_name="ratings_users_permissions", blank=True)

class Store(models.Model):
    name = models.CharField(max_length=255)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, limit_choices_to={'role': 'owner'}
    )
    email = models.EmailField(unique=True)
    address = models.TextField(max_length=400)
    average_rating = models.FloatField(default=0.0)  # Renamed from 'rating' to 'average_rating'

    def __str__(self):
        return self.name

class Rating(models.Model):
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name="ratings")  # Added related_name
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    rating = models.IntegerField()

    def __str__(self):
        return f"{self.user.username} - {self.store.name}: {self.rating}"
